package Academy;
import PageObjects.LandingPage;
import PageObjects.LoginPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import resources.base;
import org.testng.annotations.Test;

import java.io.IOException;


public class HomePageTest extends base {
    @BeforeTest
    public void initialize() throws IOException {
        driver = initializedDriver();

    }

    @Test(dataProvider ="getData")
    public void basePageNavigation(String username, String password, String text) throws IOException {
        driver.get(prop.getProperty("url"));
        driver=initializedDriver();
        driver.get("http://qaclickacademy.com");
        LandingPage l= new LandingPage(driver);
        l.getLogin().click();


        LoginPage lp=new LoginPage(driver);
        lp.getEmail().sendKeys(username);
        lp.getPassword().sendKeys(password);
        System.out.println(text);
        lp.getLogin().click();

    }
    @DataProvider
    public Object[][] getData(){
        Object[][] data= new Object[2][3];
        data[0][0]="nonrestricteduser@qu.com";
        data[0][1]="None";
        data[0][2]="Restricted User";

        data[1][0]="restricteduser@qu.com";
        data[1][1]="none111";
        data[1][2]= "non restricted user";


        return data;
    }
    @AfterTest
    public void teardown(){
        driver.close();
    }
}
