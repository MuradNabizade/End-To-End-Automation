package Academy;

import PageObjects.LandingPage;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import resources.base;

import java.io.IOException;


public class validateNavigationbarTest extends base {
    @BeforeTest
    public void initialize() throws IOException {
        driver=initializedDriver();
        driver.get(prop.getProperty("url"));
    }
    @Test
    public void basePageNavigation() throws IOException {

        LandingPage l= new LandingPage(driver);

        Assert.assertTrue(l.getNavigationBar().isDisplayed());
        

    }
    @AfterTest
    public void teardown(){
        driver.close();
    }

}
