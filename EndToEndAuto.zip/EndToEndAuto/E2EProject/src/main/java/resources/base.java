package resources;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class base {


    public WebDriver driver;
    public Properties prop;
    public WebDriver initializedDriver() throws IOException {
        //chrome

        //firefox

        //iE

        prop = new Properties();
        FileInputStream file=new FileInputStream("/Users/muradnabizade/Desktop/EndToEndAuto/E2EProject/src/main/java/resources/data.properties");

        prop.load(file);
        String browserName= prop.getProperty("browser");

        if(browserName.equals("chrome")){
            //execute in chrome driver
            System.setProperty("webdriver.chrome.driver", "/Users/muradnabizade/Downloads/chromedriver 2");
            driver=new ChromeDriver();
        } else if (browserName.equals("firefox")) {
            //
        }
        else if(browserName.equals("IE")){
            //
        }

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return driver;

    }
}
